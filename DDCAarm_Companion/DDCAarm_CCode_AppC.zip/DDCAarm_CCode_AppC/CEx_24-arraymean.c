// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 24

// Initialize a 5-element array, compute the mean, and print the result.
#include <stdio.h>

// Returns the mean value of an array of data, arr, of length len
float getMean(int arr[], int len) {
  int i;
  float mean, total = 0;	

  for (i=0; i < len; i++)
    total += arr[i];

  printf("total: %f, len: %d\n", total, len);

  mean = total / len;
  return mean;
}

int main(void) {
  int data[4] = {78, 14, 99, 27};
  float avg;

  avg = getMean(data, 4);
  
  printf("The average value is: %f.\n", avg);
}

