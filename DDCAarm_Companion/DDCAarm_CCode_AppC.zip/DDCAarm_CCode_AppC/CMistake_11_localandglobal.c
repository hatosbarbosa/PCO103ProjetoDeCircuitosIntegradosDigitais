// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 11

#include <stdio.h>

int x = 5;   // global declaration of x

int main(void)
{
  test();
  printf("x: %d\n", x);
}

/*
int test(void)
{
  int x = 3; // local declaration of x
  printf("x: %d\n", x);
}
*/

int test(void)
{
  int y = 3;
  printf("y: %d\n", y);
}

