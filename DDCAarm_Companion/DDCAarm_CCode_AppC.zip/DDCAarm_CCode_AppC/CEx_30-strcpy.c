// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 30

#include <stdio.h>

char str[10] = "Hello!";
char *str2 = "Hello!";
char str3[10];

void strcpy(char *dst, char *src);

int main()
{
  printf("Hello string: %s\n", str);
  printf("BEFORE: str2: %s, str3: %s\n", str2, str3);
  strcpy(str3, str2);
  printf("AFTER: str2: %s, str3: %s\n", str2, str3);

  return 0;
}

// Copies the source string, src, to the destination string, dst
void strcpy(char *dst, char *src)
{
  int i = 0;

  do {
    dst[i] = src[i];      // copy characters one byte at a time
  } while (src[i++]);      // until the null terminator is found
}

