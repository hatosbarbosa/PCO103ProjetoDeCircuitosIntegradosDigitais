// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 28

#include <stdio.h>

int main()
{
  int i;

  char str[10] = "Hello!";

  printf("str = %s\n", str);
  for (i=0; i<7; i++)
    printf("str[%d] = %c\n", i, str[i]);
}


