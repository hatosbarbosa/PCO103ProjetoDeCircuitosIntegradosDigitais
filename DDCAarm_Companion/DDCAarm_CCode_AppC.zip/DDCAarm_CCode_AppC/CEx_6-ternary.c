// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 6

#include <stdio.h>

int main()
{ 
  int y, a = 5, b = -10;

  y = (a > b) ? a : b; // parentheses not necessary, but makes it clearer
  printf("y = %d\n", y);

  if (a > b)	y = a;
  else			y = b;
  printf("y = %d\n", y);

}



