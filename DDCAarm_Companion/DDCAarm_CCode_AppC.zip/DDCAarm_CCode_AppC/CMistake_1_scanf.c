// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 1

#include <stdio.h>

int main(void)
{
  int a;
  printf("Enter an integer:\t");
  // scanf("%d", a); // missing & before a 
  scanf("%d", &a);
  printf("a: %d\n", a); 
}

