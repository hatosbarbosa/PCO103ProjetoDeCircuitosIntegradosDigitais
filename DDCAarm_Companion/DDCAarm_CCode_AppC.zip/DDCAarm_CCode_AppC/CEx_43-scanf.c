// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 43

// Read variables from the command line.
#include <stdio.h>

int main(void)
{
  int a;
  char str[80];
  float f;

  printf("Enter an integer.\n");
  scanf("%d", &a); 
  printf("Enter a floating point number.\n");
  scanf("%f", &f);
  printf("Enter a string.\n");
  scanf("%s", str); 	// note no & needed: str is a pointer to 
                       // the beginning of the array

  printf("a: %d, f: %f, str: %s\n", a, f, str);
}
