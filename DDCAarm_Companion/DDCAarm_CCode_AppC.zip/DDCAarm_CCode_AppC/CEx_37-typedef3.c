// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 37

#include <stdio.h>

typedef double vector[3];
typedef double matrix[3][3];

vector a = {4.5, 2.3, 7.0};
matrix b = {{3.3, 4.7, 9.2}, {2.5, 4, 9}, {3.1, 99.2, 88}};

int main(void)
{
  int i, j;

  // print a
  for (i=0; i<3;i++)
    printf("a[%d] = %f\n", i, a[i]);

  // print b
  for (i=0; i<3;i++)
    for (j=0; j<3;j++)
      printf("b[%d][%d] = %f\n", i, j, b[i][j]);

}




