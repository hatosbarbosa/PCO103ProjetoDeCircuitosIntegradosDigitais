// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Examples 15-17 

#include <stdio.h>

int main()
{
  // while
  // Compute 9! (the factorial of 9)
  int i = 1, fact = 1;

  // multiply the numbers from 1 to 9
  while (i < 10) { // while loops check the condition first
    fact *= i;
    i++;
  }
  printf("while fact: %d\n", fact);


  // do/while
  // Query user to guess a number and check it against the correct number.
  #define MAXGUESSES 3
  #define CORRECTNUM 7

  int guess, numGuesses = 0;

  do {
    printf("Guess a number between 0 and 9. You have %d more guesses.\n",
      (MAXGUESSES-numGuesses));
    scanf("%d", &guess);   // read user input
    numGuesses++;
  } while ( (numGuesses < MAXGUESSES) & (guess != CORRECTNUM) );     
  // do loop checks the condition after the first iteration

  if (guess == CORRECTNUM)
    printf("You guessed the correct number!\n");
     

fact = 1;
// for
// Computes 9!
for (i=1; i<10; i++)
  fact *= i;

printf("for fact: %d\n", fact);


}

