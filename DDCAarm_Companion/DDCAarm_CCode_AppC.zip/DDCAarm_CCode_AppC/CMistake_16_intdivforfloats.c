// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 16

#include <stdio.h>

int main(void)
{
//float x = 9 / 4;   // x = 2.0
  float x = 9.0 / 4; // x = 2.25
  
  printf("x = %f\n", x);
}

