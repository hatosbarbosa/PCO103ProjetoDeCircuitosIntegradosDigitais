// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 14

#include <stdio.h>

int main(void)
{
  int num;
  do {
    num = getNum();
//  } while (num < 100)  // missing ;
  } while (num < 100);
}

int getNum()
{ int num;

  printf("Enter a number: ");
  scanf("%d", &num);
  return num;
}

