// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 10

/*
int main(void)
{
  test();
}

void test(void)
{
  printf("Hi\n");
}
*/

void test(void)
{
  printf("Hi\n");
}

int main(void)
{
  test();
}

