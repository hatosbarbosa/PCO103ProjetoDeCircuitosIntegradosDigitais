// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 23

#include <stdio.h>

int main()
{

  // User enters 3 student scores into an array.
  long scores[3];
  int i, entered;

  printf("Please enter the student's 3 scores.\n");
  for (i=0; i<3; i++) {
    printf("Enter a score and press enter.\n");
    scanf("%d", &entered);
    scores[i] = entered;
  }
  printf("Scores: %d %d %d\n", scores[0], scores[1], scores[2]);
}

