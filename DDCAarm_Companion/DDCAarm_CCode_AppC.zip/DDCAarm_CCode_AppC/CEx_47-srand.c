// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 47

#include <stdlib.h>
#include <time.h>

int main()
{
  int x;

  srand(time(NULL));	// seed the random number generator
  x = rand() % 10; 	// random number from 0 to 9
  printf("x = %d\n", x);
}


