// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 12

#include <stdio.h>

int main(void)
{ 
/*
  int scores[3];
  scores = {93, 81, 97};
*/

  int scores[3] = {93, 81, 97};
}

