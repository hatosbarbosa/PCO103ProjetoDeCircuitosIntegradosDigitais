// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 45

#include <stdio.h>

int main(void)
{
  FILE *fptr;
  int data;

  // read in data from input file
  if ((fptr = fopen("data.txt", "r")) == NULL) {
    printf("Unable to read data.txt\n");
    exit(1);
  }

  while (!feof(fptr)) {  // check that the end of the file hasn't 
                         // been reached
    fscanf(fptr, "%d ", &data);
    printf("Read data: %d\n", data);
  }

  fclose(fptr);
} 

