// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Examples 20 and 21

#include <stdio.h>

int main()
{
  int i;

  long tmp[3];
  long scores[3]={93, 81, 97}; // scores[0]=93; scores[1]=81; scores[2]=97;

  for (i=0; i<3; i++)
    printf("scores[%d] = %d\n", i, scores[i]);

  return 0;
}

