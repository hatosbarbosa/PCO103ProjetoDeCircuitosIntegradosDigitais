// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 17

#include <stdio.h>

int main(void)
{
// int *y = 77;
  int x, *y = &x;   // y = the address of x
  *y = 77;          // x = 77

  printf("x = %d, y = %0x, address of x = %0x\n", x, y, &x);
}

