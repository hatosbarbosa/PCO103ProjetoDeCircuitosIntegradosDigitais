// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 13

#include <stdio.h>

int main(void)
{
  int i;
  int scores[3]  = {88, 79, 93};
  int scores2[3];

//  scores2 = scores;
 
  for (i=0; i<3; i++)
    scores2[i] = scores[i];

  printf("scores2: %u; scores: %u\n", scores2, scores);
}

