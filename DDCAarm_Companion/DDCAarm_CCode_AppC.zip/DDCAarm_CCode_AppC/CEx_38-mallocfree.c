// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 38

// Dynamically allocate and de-allocate an array using malloc() and free()
#include <stdlib.h>

// insert getMean() function from C Code Example C.24.
// Returns the mean value of an array of data, arr, of length len
int getMean(int arr[], int len) {
  int i, mean, total = 0;

  for (i=0; i < len; i++)
    total += arr[i];

  mean = total / len;
  return mean;
}


int main(void) {
  int len, i;
  int *nums;

  printf("How many numbers would you like to enter? ");
  scanf("%d", &len); 
  nums = malloc(len*sizeof(int));
  if (nums == NULL) printf("ERROR: out of memory.\n");
  else {
    for (i=0; i<len; i++) {
      printf("Enter number: ");
      scanf("%d", &nums[i]);
    }
    printf("The average is %d\n", getMean(nums, len));
  }  
  free(nums);
}


