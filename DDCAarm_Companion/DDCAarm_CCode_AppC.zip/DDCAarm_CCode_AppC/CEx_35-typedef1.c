// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 35

#include <stdio.h>

typedef struct contact {
  char name[30];
  int phone;
  float height; // in meters
} contact;      // defines contact as shorthand for "struct contact"

contact c1;     // now we can declare the variable as type contact

// Copies the source string, src, to the destination string, dest
void strcpy(char *dest, char *src)
{
  int i = 0;

  do {
    dest[i] = src[i];      // copy characters one byte at a time
  } while (src[i++]);      // until the null terminator is found
}


int main(void)
{
  strcpy(c1.name, "Ben Bitdiddle");  
  c1.phone = 7226993;
  c1.height = 1.82;

  printf("name: %s\n", c1.name);
  printf("phone: %d\n", c1.phone);
  printf("height: %f\n", c1.height);

}



