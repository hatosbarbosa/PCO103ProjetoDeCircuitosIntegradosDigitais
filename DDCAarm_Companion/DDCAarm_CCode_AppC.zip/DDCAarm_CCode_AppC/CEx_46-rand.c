// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 46

#include <stdlib.h>
int x, y;

int main()
{
  x = rand();      // x = a random integer
  y = rand() % 10; // y = a random number from 0 to 9
  printf("x = %d, y = %d\n", x, y);
}

