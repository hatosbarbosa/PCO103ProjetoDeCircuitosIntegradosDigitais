// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 9


void printPrompt();

int main()
{
  printPrompt();
  return 0;
}

// printPrompt() prints a user prompt to the console.
void printPrompt(void)
{
  printf("Please enter a number from 1-3:\n");
}


