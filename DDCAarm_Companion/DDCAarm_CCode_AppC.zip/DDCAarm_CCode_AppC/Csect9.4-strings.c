// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// Section C9.4

#include <stdio.h>
#include <string.h>

// copy src into dest and return dest
//char *strcpy(char *dest, char *src); 

// concatenate (append) src to the end of dest and return dest
//char *strcat(char *dest, char *src); 

// compare two strings.  Return 0 if equal, nonzero otherwise
//int strcmp(char *s1, char *s2);  

// return the length of str, not including the null termination
//int strlen(char *str);  



int main(void)
{
  char *str1 = "test1";
  char *str2 = "random";
  char str3[20];

  printf("START: str1: %s, str2: %s, str3: %s\n", str1, str2, str3);

  strcpy(str3, str1);
  printf("after strcpy: str1: %s, str2: %s, str3: %s\n", str1, str2, str3);

  strcat(str3, str2);
  printf("after strcat: str1: %s, str2: %s, str3: %s\n", str1, str2, str3);

  if (!strcmp(str1, str2))
    printf("str1 == str2\n");

  if (!strcmp(str1, str1))
    printf("str1 == str1\n");

  printf("length: str1: %s (%d), str2: %s (%d), str3: %s (%d)\n", str1, strlen(str1), 
    str2, strlen(str2), str3, strlen(str3));
}
