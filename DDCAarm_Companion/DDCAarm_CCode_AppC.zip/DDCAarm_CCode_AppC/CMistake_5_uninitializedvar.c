// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 5

#include <stdio.h>

int main(void)
{
//  int i;  // i is uninitialized 
  int i = 10;
  if (i == 10) 
    printf("hi\n");
}

