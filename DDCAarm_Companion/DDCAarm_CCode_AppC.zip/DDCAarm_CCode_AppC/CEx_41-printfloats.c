// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 41

#include <stdio.h>

int main(void)
{
  // print floating point numbers with different formats
  float pi = 3.14159, e = 2.7182, c = 2.998e8;
  printf("pi = %4.2f\ne  = %8.3f\nc  = %5.3f\n\n", pi, e, c);

}


