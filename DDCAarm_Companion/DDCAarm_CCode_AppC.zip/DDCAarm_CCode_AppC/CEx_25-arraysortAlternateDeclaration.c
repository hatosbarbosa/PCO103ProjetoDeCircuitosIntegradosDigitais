// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 25 (alternate declaration)

#include <stdio.h>

// sort the elements of the array vals of length len from lowest to highest

void sort(int *vals, int len)
//void sort(int vals[], int len)
//void sort(int vals[100], int len)
//void sort(int vals[], int len)
{
  int i, j, temp;

  for (i=0; i<len; i++) {
    for (j=i+1; j<len; j++) {
      if (vals[i] > vals[j]) {
        temp = vals[i];
        vals[i] = vals[j];
        vals[j] = temp;
      }
    }
  }
}

int testarray[5] = {4, 22, 3, 15, 99};

int main()
{
  int i;

  sort(testarray, 5);

  printf("sorted array:\t");
  for (i=0; i<5; i++) {
    printf("%d ", testarray[i]);
  }
}


