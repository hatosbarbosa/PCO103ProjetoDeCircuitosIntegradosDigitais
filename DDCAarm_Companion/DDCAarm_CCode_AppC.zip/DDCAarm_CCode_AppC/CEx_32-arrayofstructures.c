// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 32

#include <stdio.h>

struct contact {
  char name[30];
  int phone;
  float height; // in meters
};

struct contact c1;

int main(void) {
  strcpy(c1.name, "Ben Bitdiddle");  
  c1.phone = 7226993;
  c1.height = 1.82;

  struct contact classlist[200];
  classlist[0].phone = 7226993;

  printf("classlist[0].phone = %d\n", classlist[0].phone);
  printf("classlist[1].phone = %d\n", classlist[1].phone); // not initialized
}
