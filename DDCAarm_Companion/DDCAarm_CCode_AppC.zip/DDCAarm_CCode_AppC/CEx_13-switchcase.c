// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 13

#include <stdio.h>

int main()
{
  int option = 3;  // initialize to 3, could be reassigned later
  int amt;

  // assign amt depending on the value of option
  switch (option) {
    case 1:	amt = 100; printf("100\n"); break;
    case 2:	amt = 50;  printf("50\n"); break;
    case 3:	amt = 20;  printf("20\n"); break;
    case 4:	amt = 10;  printf("10\n"); break;
    default:	printf("Error: unknown option\n");
  }

  printf("amt: %d\n", amt);
  return 0;
}

