// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 8

#include <stdio.h>

int main(void)
{
  char direction, x = 'd';

/*
  switch (x) {
    case 'u':     direction = 1;
    case 'd':     direction = 2;
    case 'l':     direction = 3;
    case 'r':     direction = 4;
    default: direction = 0;
  }
  // direction = 0
s
  printf("direction: %d\n", direction);
*/

  switch (x) {
    case 'u': direction = 1; break;
    case 'd': direction = 2; break;
    case 'l': direction = 3; break;
    case 'r': direction = 4; break;
    default:  direction = 0;
  }
  // direction = 2

  printf("direction: %d\n", direction);

}

