// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 40

// Simple print function.
#include <stdio.h>

int num = 42;
int main(void) {
  printf("The answer is %d.\n", num);
}

