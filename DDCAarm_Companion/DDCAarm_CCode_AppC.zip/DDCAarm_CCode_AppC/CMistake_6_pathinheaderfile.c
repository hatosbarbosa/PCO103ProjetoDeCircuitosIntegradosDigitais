// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 6

#include <stdio.h>
// #include "myfile.h"
#include "testdir/myfile.h"

int main(void)
{
  testfunc();
}

void testfunc()
{
  printf("Testing!\n");
}


