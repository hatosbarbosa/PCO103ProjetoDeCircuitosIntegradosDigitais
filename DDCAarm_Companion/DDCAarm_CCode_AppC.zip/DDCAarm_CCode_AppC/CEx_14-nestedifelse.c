// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 14

int main()
{
  int amt, option = 3;

  // assign amt depending on the value of option
  if      (option == 1)	amt = 100;
  else if (option == 2)	amt = 50;
  else if (option == 3)	amt = 20;
  else if (option == 4)	amt = 10;
  else	printf("Error: unknown option\n");

  printf("amt = %d\n", amt);

  return 0;
}


