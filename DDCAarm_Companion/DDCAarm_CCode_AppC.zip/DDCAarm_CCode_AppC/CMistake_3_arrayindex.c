// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 3

#include <stdio.h>

int main(void)
{
  int array[10];
  int i;

  // for (i=1; i <= 10; i++)
  for (i=0; i < 10; i++)
    array[i] = i;
 
  for (i=1; i < 10; i++)
    printf("array[%d] = %d\n", i, array[i]); 
 
}


