// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 36

#include <stdio.h>

typedef unsigned char byte;
typedef char bool;
#define TRUE 1
#define FALSE 0

byte pos = 0x45;
bool loveC = TRUE;

int main(void)
{
  printf("pos: %d\nloveC: %d\n", pos, loveC);
}
