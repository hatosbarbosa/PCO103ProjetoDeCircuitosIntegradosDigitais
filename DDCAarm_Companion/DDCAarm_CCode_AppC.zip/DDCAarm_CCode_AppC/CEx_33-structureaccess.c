// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 33

#include <stdio.h>

struct contact {
  char name[30];
  int phone;
  float height; // in meters
};

int main(void) {

  struct contact classlist[200];
  classlist[0].phone = 7226993;

  printf("classlist[0].phone = %d\n", classlist[0].phone);
  printf("classlist[1].phone = %d\n", classlist[1].phone); // not initialized

  struct contact *cptr;
  cptr = &classlist[42];
  cptr->height = 1.9;

  printf("cptr->height = %f\n", cptr->height);
}

