// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 34

#include <stdio.h>

struct contact {
  char name[30];
  int phone;
  float height; // in meters
};


struct contact stretchByValue(struct contact c)
{
  c.height += 0.02;
  return c;
}

void stretchByReference(struct contact *cptr)
{
  cptr->height += 0.02;
}

int main(void)
{
  struct contact George;

  George.height = 1.4; // poor fellow has been stooped over
  printf("George height = %f\n", George.height);
  George = stretchByValue(George); // stretch for the stars
  printf("George height = %f\n", George.height);
  stretchByReference(&George);     // and stretch some more
  printf("George height = %f\n", George.height);
}

