// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 12

#include <stdio.h>

int main(void)
{
  int dispenseCandy, amt = 5;

  // If amt >= $2, prompt user and dispense candy.
  if (amt >= 2) {
    printf("Select candy.\n");
    dispenseCandy = 1;  
  }
}


