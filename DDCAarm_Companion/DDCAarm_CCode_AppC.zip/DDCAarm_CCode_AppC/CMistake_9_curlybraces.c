// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 9

#include <stdio.h>

int main(void)
{ 
  FILE *ptr = 20;  // dummy value used to demonstrate code error

/*
  if (ptr == NULL)
    printf("Unable to open file.\n");
    exit(1);
*/
  
  if (ptr == NULL) {
    printf("Unable to open file.\n");
    exit(1);
  }

  printf("Made it past exit!\n");
}

