// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 2
// Converts inches to centimeters
#include <stdio.h>

#define INCH2CM 2.54

int main(void) {
  float inch = 5.5;   // 5.5 inches
  float cm;
       
  cm = inch * INCH2CM;
  printf("%f inches = %f cm\n", inch, cm);
}

