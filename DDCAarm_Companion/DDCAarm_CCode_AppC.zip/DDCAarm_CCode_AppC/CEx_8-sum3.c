// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 8

int main()
{
  int total = sum3(4, 16, 32);
  printf("total: %d\n", total);

  return 0;
}


// Returns the sum of the three input variables
int sum3(int a, int b, int c) {
	int result = a + b + c;
	return result;
}

