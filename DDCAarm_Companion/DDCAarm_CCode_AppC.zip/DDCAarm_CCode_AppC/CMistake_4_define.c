// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 4

#include <stdio.h>

// replaces NUM with "= 4" in code
// #define NUM = 4
#define NUM 4

int main(void)
{
  int y = NUM;
  printf("y = %d\n", y);
}

