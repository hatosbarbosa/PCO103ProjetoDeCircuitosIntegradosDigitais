// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 18

#include <stdio.h>

int main()
{
  int x;
  int y;

  // Example pointer manipulations
  int salary1, salary2;  // 32-bit numbers
  int *ptr;  // a pointer specifying the address of an   int variable

  salary1 = 67500;       // salary1 = $67,500 = 0x000107AC
  ptr = &salary1;        // ptr = 0x0070, the address of salary1
  salary2 = *ptr + 1000; /* dereference ptr to give the contents of 
                            address 70 = $67,500, then 
                            add $1,000 and set salary2 to $68,500 */


  printf("salary2: %d\n", salary2);
  x = sizeof(ptr);
  y = sizeof(salary1);


  printf("ptr size: %d\nsalary1 size: %d\n", x, y);

  return 0;
}

