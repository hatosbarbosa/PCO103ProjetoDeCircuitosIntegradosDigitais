// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 7

#include <stdio.h>

int main()
{
  FILE *out;
  out = fopen("CCode07.txt", "w");

  char a = 44 / 14;
  char b = 44 % 14;
  char c = 0x2C && 0xE; //0b101100 && 0b1110
  char d = 0x2C || 0xE; //0b101100 || 0b1110
  char e = 0x2C & 0xE;  //0b101100 &  0b1110
  char f = 0x2C | 0xE;  //0b101100 |  0b1110
  char g = 0x2C ^ 0xE;  //0b101100 ^  0b1110
  char h = 0xE << 2;    //0b1110   << 2
  char i = 0x2C >> 3;   //0b101100 >> 3
  char x = 14; x += 2;

  fprintf(out, "a = %d\n", a);
  fprintf(out, "b = %d\n", b);
  fprintf(out, "c = %d\n", c);
  fprintf(out, "d = %d\n", d);
  fprintf(out, "e = %d\n", e);
  fprintf(out, "f = %d\n", f);
  fprintf(out, "g = %d\n", g);
  fprintf(out, "h = %d\n", h);
  fprintf(out, "i = %d\n", i);
  fprintf(out, "x = %d\n", x);

  char y =  0x2C; // y =  0b101100
  y &= 0xF;       // y &= 0b1111
  fprintf(out, "y = %d\n", y);


  x = 14; y = 44;
  y = y + x++;
  fprintf(out, "x = %d, y = %d\n", x, y);


  x = 14; y = 44;
  y = y + ++x;
  fprintf(out, "x = %d, y = %d\n", x, y);
 
  fclose(out);
  return 0;
} 

