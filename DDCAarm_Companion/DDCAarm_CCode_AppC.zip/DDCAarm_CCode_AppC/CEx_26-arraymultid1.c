// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 26

#include <stdio.h>

// initialize array at declaration
 int grades[10][8] =
    { {100, 107, 99,  101, 100, 104, 109, 117},
      {103, 101, 94,  101, 102, 106, 105, 110},
      {101, 102, 92,  101, 100, 107, 109, 110},
      {114, 106, 95,  101, 100, 102, 102, 100},
      {98,  105, 97,  101, 103, 104, 109, 109},
      {105, 103, 99,  101, 105, 104, 101, 105},
      {103, 101, 100, 101, 108, 105, 109, 100},
      {100, 102, 102, 101, 102, 101, 105, 102},
      {102, 106, 110, 101, 100, 102, 120, 103},
      {99,  107, 98,  101, 109, 104, 110, 108} };

int main(void)
{
  int i,j;

  for (i=0; i<10; i++) {
    for (j=0; j<8; j++)
      printf("%d, ", grades[i][j]);
    printf("\n");
  }
}


