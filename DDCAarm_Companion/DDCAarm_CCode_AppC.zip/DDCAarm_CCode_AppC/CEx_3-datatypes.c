// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 3

#include <stdio.h>

// Examples of several data types and their binary representations
unsigned char x = 42;		// x = 00101010
short y = -10;			// y = 11111111 11110110
unsigned long z = 0;		// z = 00000000 00000000 00000000 00000000

int main()
{
	int sizex, sizey, sizez;
	sizex = sizeof(x);
	sizey = sizeof(y);
	sizez = sizeof(z);

	printf("Values:    x = %d, y = %d, z = %d\n", x, y, z);
	printf("Sizes:     x = %d, y = %d, z = %d\n", sizex, sizey, sizez);
	printf("Addresses: x = %u, y = %u, z = %u\n", &x, &y, &z);

	return 0;
}

