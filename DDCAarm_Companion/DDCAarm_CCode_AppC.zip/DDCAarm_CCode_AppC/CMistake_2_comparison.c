// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 2

#include <stdio.h>

int main(void)
{
  int x = 24;

//  if (x = 1)  // always evaluates as TRUE
  if (x == 1)
    printf("Found!\n");
}

