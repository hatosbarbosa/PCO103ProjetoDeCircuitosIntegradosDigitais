// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 1 
// Writes "Hello world!" to the console
#include <stdio.h>

int main(void){
  printf("Hello world!\n");
}

