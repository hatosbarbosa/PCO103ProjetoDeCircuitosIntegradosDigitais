// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 19

#include <stdio.h>

void quadruple(int *a)
{
	*a = *a * 4;
}

int main(void)
{
	int x;

	x = 5;
	printf("x before: %d\n", x);
	quadruple(&x);
	printf("x after: %d\n", x);
	return 0;
}

