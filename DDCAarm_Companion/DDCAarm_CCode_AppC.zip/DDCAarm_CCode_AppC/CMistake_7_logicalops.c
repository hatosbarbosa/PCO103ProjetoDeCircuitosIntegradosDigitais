// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Mistake 7

#include <stdio.h>

int main(void)
{
  char x=!5;    // logical NOT: x = 0
  char y=5||2;  // logical OR:  x = 1
  char z=5&&2;  // logical AND: x = 1
  printf("x: %d, y: %d, z: %d\n", x, y, z);

  char a=~5; // bitwise NOT: x = 0b11111010
  char b=5|2;// bitwise OR:  x = 0b00000111
  char c=5&2;// logical AND: x = 0b00000000
  printf("a: %d, b: %d, c: %d\n", a, b, c);
}


