// Digital Design and Computer Architecture
// David Harris and Sarah Harris, 2011-2021
// Appendix C
// C Example 29

#include <stdio.h>

int main()
{
  int i;

  char *str = "Hello!";
  printf("str: %s", str);
}


